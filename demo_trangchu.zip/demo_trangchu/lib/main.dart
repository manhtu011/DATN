import 'package:flutter/material.dart';
import 'package:demo_trangchu/Navigationbar.dart';

void main() => runApp((NavigationBar()));
